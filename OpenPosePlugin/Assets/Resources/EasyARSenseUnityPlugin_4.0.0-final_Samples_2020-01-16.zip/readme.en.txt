This package contains samples for EasyAR Sense Unity Plugin.
Please read the documents on EasyAR website for how to use guide: https://www.easyar.com/view/support.html

Samples:
  AllSamplesLauncher
    - A launcher scene to load all samples. You need to add all sample scenes from Assets/Samples/Scenes subfolders to the build settings use Unity menu File->Build Settings...

  WorldSensing/SpatialMap_SparseSpatialMap
    - Demonstrate how to use sparse SpatialMap
    - Demonstrate how to create sparse SpatialMap
    - Demonstrate how to put virtual objects onto SpatialMap
    - Demonstrate how to preview persistence contents
    - Demonstrate how to localize multiple maps and show contents on them

  WorldSensing/MapLocalizing_Sparse
    - Demonstrate how to use the sparse SpatialMap uploaded into the database (e.g. created from SpatialMap_SparseSpatialMap sample)
    - Demonstrate how to localize sparse SpatialMap and put virtual objects onto SpatialMap

  WorldSensing/SpatialMap_Dense_BallGame
    - Demonstrate how to use dense SpatialMap
    - Demonstrate how to render dense SpatialMap mesh
    - Demonstrate how to use dense SpatialMap to do collision and occlusion

  WorldSensing/SpatialMap_Sparse_ImageTarget
    - Demonstrate how to use sparse SpatialMap and image tracking together

  WorldSensing/MapBuilding_Sparse
    - Demonstrate how to build sparse SpatialMap

  WorldSensing/MapBuilding_Sparse_Dense
    - Demonstrate how to build sparse SpatialMap and dense SpatialMap together

  WorldSensing/MotionTracking
    - Demonstrate how to use motion tracking
    - Demonstrate how to fallback to ARKit/ARCore when EasyAR motion tracker not available

  WorldSensing/MotionTracking_ImageTarget
    - Demonstrate how to use motion tracking and image tracking together

  WorldSensing/SurfaceTracking
    - Demonstrate how to use surface tracking

  WorldSensing/SurfaceTracking_ImageTarget
    - Demonstrate how to use surface tracking and image tracking together

  ObjectSensing/ImageTracking_Targets
    - Demonstrate different methods to create targets
    - Demonstrate how to dynamically create targets
    - Demonstrate how to create a target from ImageTargetData
    - Demonstrate how to load and unload targets
    - Demonstrate how to use different center mode
    - Demonstrate how to use different horizontal flip mode

  ObjectSensing/ImageTracking_Video
    - Demonstrate how to load video with Unity VideoPlayer and play video on target
    - Demonstrate how to load video with Unity VideoPlayer and play transparent video with custom shader
    - Demonstrate how to change the video aspect ratio (Unity VideoPlayer feature) to fit image target

  ObjectSensing/ImageTracking_MotionExtend
    - Demonstrate how to extend tracking started from image

  ObjectSensing/ImageTracking_CloudRecognition
    - Demonstrate how to use cloud recognition
    - Demonstrate how to create and use offline cache
    - Demonstrate how to stop web request when tracking

  ObjectSensing/ImageTracking_TargetOnTheFly
    - Demonstrate how to create image target directly from real-time camera image and load it into tracker as a target

  ObjectSensing/ImageTracking_Coloring3D
    - Demonstrate how to create a coloring book and "convert" book image into 3D at real-time

  ObjectSensing/MultiTarget_SingleTracker
    - Demonstrate how to track multiple targets simultaneously using single tracker

  ObjectSensing/MultiTarget_MultiTracker
    - Demonstrate how to track multiple targets simultaneously using multiple trackers

  ObjectSensing/MultiTarget_SameImage
    - Demonstrate how to track multiple same targets simultaneously
    - Demonstrate how to load image target using custom code

  ObjectSensing/MultiTarget_MultiType
    - Demonstrate how to track multiple type of targets simultaneously

  ObjectSensing/ObjectTracking
    - Demonstrate how to track 3D objects

  DeviceSupport/Camera_VideoCamera
    - Demonstrate how to open/close camera
    - Demonstrate how to switch camera
    - Demonstrate how to get camera image texture
    - Demonstrate how to control camera display
    - Demonstrate how to horizontally flip camera image

  DeviceSupport/VideoRecording
    - Demonstrate how to do recording

Image Markers:
  You can find image markers under folders named StreamingAssets.
