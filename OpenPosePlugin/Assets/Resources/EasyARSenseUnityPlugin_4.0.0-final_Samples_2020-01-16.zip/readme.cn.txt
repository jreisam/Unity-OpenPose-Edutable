﻿本包中包含EasyAR Sense Unity Plugin的样例。
请阅读EasyAR网站上文档来了解应该如何来使用这些样例：https://www.easyar.cn/view/support.html

样例:
  AllSamplesLauncher
    - sample启动器，可以通过启动器加载所有样例。你需要从 Assets/Samples/Scenes 的子文件夹中添加所有样例场景到Unity的build settings中。可以使用Unity菜单选项 File->Build Settings... 来添加

  WorldSensing/SpatialMap_SparseSpatialMap
    - 演示如何使用稀疏空间地图
    - 演示如何创建稀疏空间地图
    - 演示如何在稀疏空间地图上摆放虚拟物体
    - 演示如何预览持久化的内容
    - 演示如何定位多张地图并展示上面的内容

  WorldSensing/MapLocalizing_Sparse
    - 演示如何使用上传到SpatialMap库（比如使用SpatialMap_SparseSpatialMap样例创建）的稀疏空间地图
    - 演示如何定位稀疏空间地图并在上面摆放虚拟物体

  WorldSensing/SpatialMap_Dense_BallGame
    - 演示如何使用稠密空间地图
    - 演示如何渲染稠密空间地图网格
    - 演示如何使用稠密空间地图实现碰撞和遮挡

  WorldSensing/SpatialMap_Sparse_ImageTarget
    - 演示如何同时使用稀疏空间地图和图像跟踪

  WorldSensing/MapBuilding_Sparse
    - 演示如何构建稀疏空间地图

  WorldSensing/MapBuilding_Sparse_Dense
    - 演示如何同时构建稀疏空间地图和稠密空间地图

  WorldSensing/MotionTracking
    - 演示如何使用运动跟踪
    - 演示如何在不支持EasyAR运动跟踪的时候自动使用ARKit/ARCore

  WorldSensing/MotionTracking_ImageTarget
    - 演示如何同时使用运动跟踪和图像跟踪

  WorldSensing/SurfaceTracking
    - 演示如何使用表面跟踪

  WorldSensing/SurfaceTracking_ImageTarget
    - 演示如何同时使用表面跟踪和图像跟踪

  ObjectSensing/ImageTracking_Targets
    - 演示创建target的不同方法
    - 演示动态创建target
    - 演示通过ImageTargetData创建target的方法
    - 演示如何加载和卸载target
    - 演示如何使用不同中心模式（center mode）
    - 演示如何使用不同的水平翻转模式

  ObjectSensing/ImageTracking_Video
    - 演示如何使用Unity VideoPlayer加载并在target上播放视频
    - 演示如何使用Unity VideoPlayer加载视频，用自定义shader实现透明视频播放
    - 演示如何修改视频 aspect ratio （Unity VideoPlayer 功能） 适配image target

  ObjectSensing/ImageTracking_MotionExtend
    - 演示如何从图像扩展跟踪

  ObjectSensing/ImageTracking_CloudRecognition
    - 演示如何使用云识别
    - 演示如何创建和使用本地缓存
    - 演示如何在跟踪是停止网络请求

  ObjectSensing/ImageTracking_TargetOnTheFly
    - 演示如何直接从相机图像中实时创建target并load到tracker中

  ObjectSensing/ImageTracking_Coloring3D
    - 演示如何创建“AR涂涂乐”，使绘图书中的图像实时“转换”成3D

  ObjectSensing/MultiTarget_SingleTracker
    - 演示如何使用一个tracker同时跟踪多个目标

  ObjectSensing/MultiTarget_MultiTracker
    - 演示如何使用多个tracker同时跟踪多个目标

  ObjectSensing/MultiTarget_SameImage
    - 演示如何同时跟踪多个相同目标
    - 演示如何使用自定义代码加载图像目标

  ObjectSensing/MultiTarget_MultiType
    - 演示如何同时跟踪多个不同类型的目标

  ObjectSensing/ObjectTracking
    - 演示如何跟踪3D物体

  DeviceSupport/Camera_VideoCamera
    - 演示如何打开/关闭camera
    - 演示如何切换camera
    - 演示如何获取camera图像贴图
    - 演示如何控制camera显示
    - 演示如何水平翻转camera图像

  DeviceSupport/VideoRecording
    - 演示如何录屏

图片Markers:
  你可以在名字为StreamingAssets的文件夹中找到样例中使用的图片marker。
